package dao;

import entidades.Area;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Pruebas unitarias para los métodos públicos de AreaDAO.
 * @author Jatniel Martínez
 */
public class AreaDAOTest {
  
  public AreaDAOTest() {
  }
  
  @Before
  public void setUp() {
    System.out.println("Inicia método");
  }
  
  @After
  public void tearDown() {
    System.out.println("Termina método");
  }

  /**
   * Prueba del método consultarElementos, de la clase AreaDAO.
   * Se prueba si la lista resultante es igual a la esperada.
   */
  @Test
  public void testConsultarElementos() {
    System.out.println("consultarElementos");
    AreaDAO instancia = new AreaDAO();
    List<Area> esperado = new ArrayList<>();
    esperado.add(new Area(1, "Centro de cómputo de economía", "1", "Facultad de economía"));
    esperado.add(new Area(2, "Centro de cómputo de estadística", "2", "FEI"));
    esperado.add(new Area(3, "Centro de cómputo de informática", "3", "FEI"));
    esperado.add(new Area(4, "Centro de cómputo de geografía", "4", "Facultad de geografía"));
    esperado.add(new Area(5, "Servicios informáticos USBI", "5", "USBI"));
    List<Area> noEsperado = new ArrayList<>();
    noEsperado.add(new Area(0, "", "", ""));
    List<Area> result = instancia.consultarElementos();
    assertEquals(esperado, result);
    assertNotEquals(noEsperado, result);
  }

}
