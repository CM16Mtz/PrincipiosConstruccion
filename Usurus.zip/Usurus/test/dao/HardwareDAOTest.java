package dao;

import entidades.Area;
import entidades.Hardware;
import entidades.Licencia;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Pruebas unitarias para los métodos públicos de HardwareDAO.
 * @author Jatniel Martínez
 */
public class HardwareDAOTest {
  
  public HardwareDAOTest() {
  }
  
  @Before
  public void setUp() {
    System.out.println("Inicia método");
  }
  
  @After
  public void tearDown() {
    System.out.println("Termina método");
  }

  /**
   * Prueba del método consultarElementos, de la clase HardwareDAO.
   * Se prueba si la lista resultante es igual a la esperada.
   */
  @Test
  public void testConsultarElementos() {
    System.out.println("consultarElementos");
    HardwareDAO instance = new HardwareDAO();
    List<Hardware> esperado = new ArrayList<>();
    esperado.add(new Hardware(1, "PC de escritorio", "Óptimo", "Dell", 5, 436, "PC",
        new Licencia(1, 10, new Date(1548952200000l), new Date(1533173400000l), "Dell"),
        new Area(3, "Centro de cómputo de informática", "3", "FEI")));
    esperado.add(new Hardware(2, "PC de escritorio", "Óptimo", "HP", 1, 123, "PC",
        new Licencia(2, 20, new Date(1548952200000l), new Date(1533173400000l), "HP"),
        new Area(3, "Centro de cómputo de informática", "3", "FEI")));
    esperado.add(new Hardware(3, "PC de escritorio", "Óptimo", "Lenovo", 2, 225, "PC",
        new Licencia(3, 30, new Date(1548952200000l), new Date(1533173400000l), "Lenovo"),
        new Area(3, "Centro de cómputo de informática", "3", "FEI")));
    esperado.add(new Hardware(4, "PC de escritorio", "Óptimo", "Mac", 4, 101, "Mac",
        new Licencia(4, 40, new Date(1548952200000l), new Date(1533173400000l), "Apple"),
        new Area(1, "Centro de cómputo de economía", "1", "Facultad de economía")));
    esperado.add(new Hardware(5, "Proyector", "Con fallas", "Optoma", 1, 396, "Proyector",
        new Licencia(6, 110, new Date(1548952200000l), new Date(1533173400000l), "Optoma"),
        new Area(3, "Centro de cómputo de informática", "3", "FEI")));
    List<Hardware> noEsperado = new ArrayList<>();
    noEsperado.add(new Hardware(0, "", "", "", 0, 0, "", null, null));
    List<Hardware> resultado = instance.consultarElementos();
    assertEquals(esperado, resultado);
    assertNotEquals(noEsperado, resultado);
  }

  /**
   * Prueba del elemento insertarElemento, de la clase HardwareDAO.
   * Se prueba si la inserción fue exitosa, comparando los ids generados.
   */
  @Test
  public void testInsertarElemento() {
    System.out.println("insertarElemento");
    Hardware elemento = new Hardware(
        "Adaptador VGA para cable HDMI", "Ocupado", "Adaptador", 6, 453, "Adaptador",
        new Licencia(7, 1, new Date(1548952200000l), new Date(1533173400000l), "Microsoft"),
        new Area(3, "Centro de cómputo de informática", "3", "FEI"));
    HardwareDAO instance = new HardwareDAO();
    int esperado = 6;
    int noEsperado = 0;
    int resultado = instance.insertarElemento(elemento);
    assertEquals(esperado, resultado);
    assertNotEquals(noEsperado, resultado);
  }

  /**
   * Prueba del método eliminarElemento, de la clase HardwareDAO.
   * Se prueba si la eliminación fue exitosa.
   */
  @Test
  public void testEliminarElemento() {
    System.out.println("eliminarElemento");
    Hardware elemento = new Hardware(
        "Adaptador VGA para cable HDMI", "Ocupado", "Adaptador", 6, 453, "Adaptador",
        new Licencia(7, 1, new Date(1548952200000l), new Date(1533173400000l), "Microsoft"),
        new Area(3, "Centro de cómputo de informática", "3", "FEI"));
    HardwareDAO instance = new HardwareDAO();
    instance.eliminarElemento(elemento);
    fail("Debió haber aparecido un mensaje confirmando la eliminación");
  }

  /**
   * Prueba del método actualizarElemento, de la clase HardwareDAO.
   * Se prueba si la actualización fue exitosa.
   */
  @Test
  public void testActualizarElemento() {
    System.out.println("actualizarElemento");
    Hardware elemento = new Hardware(1, "PC de escritorio", "Deficiente", "Dell", 5, 436, "PC",
        new Licencia(1, 10, new Date(1548952200000l), new Date(1533173400000l), "Dell"),
        new Area(3, "Centro de cómputo de informática", "3", "FEI"));
    HardwareDAO instance = new HardwareDAO();
    instance.actualizarElemento(elemento);
    fail("Debió haber aparecido un mensaje confirmando la actualización");
  }

  /**
   * Prueba del método buscarElemento, de la clase HardwareDAO.
   * Se prueba si el elemento recuperado es igual al esperado.
   */
  @Test
  public void testBuscarElemento() {
    System.out.println("buscarElemento");
    Object parametro = 101;
    HardwareDAO instance = new HardwareDAO();
    Hardware esperado = new Hardware(4, "PC de escritorio", "Óptimo", "Mac", 4, 101, "Mac",
        new Licencia(4, 40, new Date(1548952200000l), new Date(1533173400000l), "Apple"),
        new Area(1, "Centro de cómputo de economía", "1", "Facultad de economía"));
    Hardware noEsperado = null;
    Hardware resultado = instance.buscarElemento(parametro);
    assertEquals(esperado, resultado);
    assertNotEquals(noEsperado, resultado);
  }
  
}
