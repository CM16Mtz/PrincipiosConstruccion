package dao;

import entidades.Area;
import entidades.Dictamen;
import entidades.Hardware;
import entidades.Licencia;
import entidades.ReporteFalla;
import entidades.TecnicoAcademico;
import java.sql.Date;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Pruebas unitarias para los métodos públicos de AreaDAO.
 * @author Jatniel Martínez
 */
public class DictamenDAOTest {
  
  public DictamenDAOTest() {
  }
  
  @Before
  public void setUp() {
    System.out.println("Inicia método");
  }
  
  @After
  public void tearDown() {
    System.out.println("Termina método");
  }
  
  /**
   * Prueba del método insertarElemento, de la clase DictamenDAO.
   * Se prueba si la inserción fue exitosa, comparando los ids generados.
   */
  @Test
  public void testInsertarElemento() {
    System.out.println("insertarElemento");
    Dictamen elemento = new Dictamen("Este hardware necesita reparación inmediata",
        new Date(1544399419), "Ninguna", "Reparación",
        new ReporteFalla(1, "La imagen se ve morada", 1,
        new Hardware(5, "Proyector", "Con fallas", "Optoma", 1, 396, "Proyector",
        new Licencia(6, 110, new Date(1548952200000l), new Date(1533173400000l), "Optoma"),
        new Area(3, "Centro de cómputo de informática", "3", "FEI")),
        new TecnicoAcademico(
        2, "magazo@gmail.com", "Informática", "Celso Márquez Cabeza", "40235", "2281407336")),
        new TecnicoAcademico(
        2, "magazo@gmail.com", "Informática", "Celso Márquez Cabeza", "40235", "2281407336"));
    DictamenDAO instance = new DictamenDAO();
    int esperado = 3;
    int noEsperado = 2;
    int resultado = instance.insertarElemento(elemento);
    assertEquals(esperado, resultado);
    assertNotEquals(noEsperado, resultado);
  }
  
}
