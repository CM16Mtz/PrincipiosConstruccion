package dao;

import entidades.Area;
import entidades.Hardware;
import entidades.Licencia;
import entidades.ReporteFalla;
import entidades.TecnicoAcademico;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Pruebas unitarias para los métodos públicos de ReporteFallaDAO.
 * @author Jatniel Martínez
 */
public class ReporteFallaDAOTest {
  
  public ReporteFallaDAOTest() {
  }
  
  @Before
  public void setUp() {
    System.out.println("Inicia método");
  }
  
  @After
  public void tearDown() {
    System.out.println("Termina método");
  }

  /**
   * Prueba del método consultarElementos, de la clase ReporteFallaDAO.
   * Se prueba si la lista resultante es igual a la esperada.
   */
  @Test
  public void testConsultarElementos() {
    System.out.println("consultarElementos");
    ReporteFallaDAO instance = new ReporteFallaDAO();
    List<ReporteFalla> esperado = new ArrayList<>();
    esperado.add(new ReporteFalla(1, "La imagen se ve morada", 1,
        new Hardware(5, "Proyector", "Con fallas", "Optoma", 1, 396, "Proyector",
            new Licencia(6, 110, new Date(1548952200000l), new Date(1533173400000l), "Optoma"),
            new Area(3, "Centro de cómputo de informática", "3", "FEI")),
        new TecnicoAcademico(2, "magazo@gmail.com", "Informática", "Celso Márquez Cabeza", "40235",
            "2281407336")));
    List<ReporteFalla> noEsperado = new ArrayList<>();
    List<ReporteFalla> resultado = instance.consultarElementos();
    assertEquals(esperado, resultado);
    assertNotEquals(noEsperado, resultado);
  }
  
}
