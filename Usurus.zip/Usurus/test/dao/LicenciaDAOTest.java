package dao;

import entidades.Licencia;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Pruebas unitarias para los métodos públicos de LicenciaDAO.
 * @author Jatniel Martínez
 */
public class LicenciaDAOTest {
  
  public LicenciaDAOTest() {
  }
  
  @Before
  public void setUp() {
    System.out.println("Inicia método");
  }
  
  @After
  public void tearDown() {
    System.out.println("Termina método");
  }

  /**
   * Prueba del método consultarElementos, de la clase LicenciaDAO.
   * Se prueba si la lista resultante es igual a la esperada.
   */
  @Test
  public void testConsultarElementos() {
    System.out.println("consultarElementos");
    LicenciaDAO instance = new LicenciaDAO();
    List<Licencia> esperado = new ArrayList<>();
    esperado.add(new Licencia(1, 10, new Date(1548952200000l), new Date(1533173400000l), "Dell"));
    esperado.add(new Licencia(2, 20, new Date(1548952200000l), new Date(1533173400000l), "HP"));
    esperado.add(new Licencia(3, 30, new Date(1548952200000l), new Date(1533173400000l), "Lenovo"));
    esperado.add(new Licencia(4, 40, new Date(1548952200000l), new Date(1533173400000l), "Apple"));
    esperado.add(new Licencia(
        5, 100, new Date(1548952200000l), new Date(1533173400000l), "Logitech"));
    esperado.add(new Licencia(
        6, 110, new Date(1548952200000l), new Date(1533173400000l), "Optoma"));
    esperado.add(new Licencia(
        7, 1, new Date(1548952200000l), new Date(1533173400000l), "Microsoft"));
    esperado.add(new Licencia(8, 80, new Date(1548952200000l), new Date(1533173400000l), "Oracle"));
    esperado.add(new Licencia(9, 25, new Date(1548952200000l), new Date(1533173400000l), "Linux"));
    List<Licencia> noEsperado = new ArrayList<>();
    esperado.add(new Licencia(0, 0, null, null, ""));
    List<Licencia> resultado = instance.consultarElementos();
    assertEquals(esperado, resultado);
    assertNotEquals(noEsperado, resultado);
  }

}
