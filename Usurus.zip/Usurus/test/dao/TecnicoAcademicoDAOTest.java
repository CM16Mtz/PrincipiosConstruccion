package dao;

import entidades.TecnicoAcademico;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Pruebas unitarias para los métodos públicos de SoftwareDAO.
 * @author Jatniel Martínez
 */
public class TecnicoAcademicoDAOTest {
  
  public TecnicoAcademicoDAOTest() {
  }
  
  @Before
  public void setUp() {
    System.out.println("Inicia método");
  }
  
  @After
  public void tearDown() {
    System.out.println("Termina método");
  }

  /**
   * Prueba del método consultarElementos, de la clase TecnicoAcademicoDAO.
   * Se prueba si la lista resultante es igual a la esperada.
   */
  @Test
  public void testConsultarElementos() {
    System.out.println("consultarElementos");
    TecnicoAcademicoDAO instance = new TecnicoAcademicoDAO();
    List<TecnicoAcademico> esperado = new ArrayList<>();
    esperado.add(new TecnicoAcademico(
        1, "jefazo@gmail.com", "Informática", "Jorge Sánchez Esquivel", "39283", "2282734809"));
    esperado.add(new TecnicoAcademico(
        2, "magazo@gmail.com", "Informática", "Celso Márquez Cabeza", "40235", "2281407336"));
    esperado.add(new TecnicoAcademico(
        3, "santo_iii@gmail.com", "Estadística", "Miguel Solar Thanos", "41053", "2282183204"));
    esperado.add(new TecnicoAcademico(
        4, "yosoygroot@outlook.com", "Economía", "Gabriel Huerta Pérez", "23945", "2281492102"));
    esperado.add(new TecnicoAcademico(
        5, "jedi_MX@outlook.com", "Geografía", "María de Luna Cardozo", "84290", "2951400228"));
    List<TecnicoAcademico> noEsperado = new ArrayList<>();
    noEsperado.add(new TecnicoAcademico(0, "", "", "", "", ""));
    List<TecnicoAcademico> resultado = instance.consultarElementos();
    assertEquals(esperado, resultado);
    assertNotEquals(noEsperado, resultado);
  }

  /**
   * Prueba del método insertarElemento, de la clase TecnicoAcademicoDAO.
   * Se prueba si la inserción fue exitosa, comparando los ids generados.
   */
  @Test
  public void testInsertarElemento() {
    System.out.println("insertarElemento");
    TecnicoAcademico elemento = new TecnicoAcademico("jatnielmtz@gmail.com", "Informática",
        "Jatniel Jasdekj Martínez Sosa", "01234", "2281595972");
    TecnicoAcademicoDAO instance = new TecnicoAcademicoDAO();
    int esperado = 6;
    int noEsperado = 0;
    int resultado = instance.insertarElemento(elemento);
    assertEquals(esperado, resultado);
    assertNotEquals(noEsperado, resultado);
  }

  /**
   * Prueba del método elminarElemento, de la clase TecnicoAcademicoDAO.
   * Se prueba si la eliminación fue exitosa.
   */
  @Test
  public void testEliminarElemento() {
    System.out.println("eliminarElemento");
    TecnicoAcademico elemento = new TecnicoAcademico("jatnielmtz@gmail.com", "Informática",
        "Jatniel Jasdekj Martínez Sosa", "01234", "2281595972");
    TecnicoAcademicoDAO instance = new TecnicoAcademicoDAO();
    instance.eliminarElemento(elemento);
    System.out.println("Sólo se espera que cargue un mensaje confirmando la eliminación");
  }

  /**
   * Prueba del método actualizarElemento, de la clase TecnicoAcademicoDAO.
   * Se prueba si la actualización fue exitosa.
   */
  @Test
  public void testActualizarElemento() {
    System.out.println("actualizarElemento");
    TecnicoAcademico elemento = new TecnicoAcademico(
        5, "jedi_MX@outlook.com", "Geografía", "María de Luna Cardozo", "84290", "2951400228");
    TecnicoAcademicoDAO instance = new TecnicoAcademicoDAO();
    instance.actualizarElemento(elemento);
    System.out.println("Sólo se espera que cargue un mensaje confirmando la actualización");
  }

  /**
   * Prueba del método buscarElemento, de la clase TecnicoAcademicoDAO.
   * Se prueba si el elemento recuperado es igual al esperado.
   */
  @Test
  public void testBuscarElemento() {
    System.out.println("buscarElemento");
    Object parametro = "23945";
    TecnicoAcademicoDAO instance = new TecnicoAcademicoDAO();
    TecnicoAcademico esperado = new TecnicoAcademico(
        4, "yosoygroot@outlook.com", "Economía", "Gabriel Huerta Pérez", "23945", "2281492102");
    TecnicoAcademico noEsperado = null;
    TecnicoAcademico resultado = instance.buscarElemento(parametro);
    assertEquals(esperado, resultado);
    assertNotEquals(noEsperado, resultado);
  }
  
}
