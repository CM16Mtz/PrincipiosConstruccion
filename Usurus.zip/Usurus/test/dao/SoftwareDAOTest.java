package dao;

import entidades.Licencia;
import entidades.Software;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Pruebas unitarias para los métodos públicos de SoftwareDAO.
 * @author Jatniel Martínez
 */
public class SoftwareDAOTest {
  
  public SoftwareDAOTest() {
  }
  
  @Before
  public void setUp() {
    System.out.println("Inicia método");
  }
  
  @After
  public void tearDown() {
    System.out.println("Termina método");
  }

  /**
   * Prueba del método consultarElementos, de la clase SoftwareDAO.
   * Se prueba si la lista resultante es igual a la esperada.
   */
  @Test
  public void testConsultarElementos() {
    System.out.println("consultarElementos");
    SoftwareDAO instance = new SoftwareDAO();
    List<Software> esperado = new ArrayList<>();
    esperado.add(new Software(1, "Windows 10", "Ninguna", 8, new Licencia(
        7, 1, new Date(1548952200000l), new Date(1533173400000l), "Microsoft")));
    esperado.add(new Software(2, "Mac OS X", "Ninguna", 17, new Licencia(
        4, 40, new Date(1548952200000l), new Date(1533173400000l), "Apple")));
    esperado.add(new Software(3, "Ubuntu", "Ninguna", 16, new Licencia(
        9, 25, new Date(1548952200000l), new Date(1533173400000l), "Linux")));
    esperado.add(new Software(4, "Debian", "Ninguna", 10, new Licencia(
        9, 25, new Date(1548952200000l), new Date(1533173400000l), "Linux")));
    esperado.add(new Software(5, "Java Development Kit", "Ninguna", 8, new Licencia(
        8, 80, new Date(1548952200000l), new Date(1533173400000l), "Oracle")));
    List<Software> noEsperado = new ArrayList<>();
    noEsperado.add(new Software(0, "", "", 0, null));
    List<Software> resultado = instance.consultarElementos();
    assertEquals(esperado, resultado);
    assertNotEquals(noEsperado, resultado);
  }

  /**
   * Prueba del método insertarElemento, de la clase SoftwareDAO.
   * Se prueba si la inserción fue exitosa, comparando los ids generados.
   */
  @Test
  public void testInsertarElemento() {
    System.out.println("insertarElemento");
    Software elemento = new Software("MySQL Installer", "Ninguna", 5, new Licencia(
        8, 80, new Date(1548952200000l), new Date(1533173400000l), "Oracle"));
    SoftwareDAO instance = new SoftwareDAO();
    int esperado = 6;
    int noEsperado = 0;
    int resultado = instance.insertarElemento(elemento);
    assertEquals(esperado, resultado);
    assertNotEquals(noEsperado, resultado);
  }

  /**
   * Prueba del método eliminarElemento, de la clase SoftwareDAO.
   * Se prueba si la eliminación fue exitosa.
   */
  @Test
  public void testEliminarElemento() {
    System.out.println("eliminarElemento");
    Software elemento = new Software(6, "MySQL Installer", "Ninguna", 5, new Licencia(
        8, 80, new Date(1548952200000l), new Date(1533173400000l), "Oracle"));
    SoftwareDAO instance = new SoftwareDAO();
    instance.eliminarElemento(elemento);
    System.out.println("Sólo se espera que cargue un mensaje confirmando la eliminación");
  }

  /**
   * Prueba del método actualizarElemento, de la clase SoftwareDAO.
   * Se prueba si la actualización fue exitosa.
   */
  @Test
  public void testActualizarElemento() {
    System.out.println("actualizarElemento");
    Software elemento = new Software(5, "JDK", "Ninguna", 8, new Licencia(
        8, 80, new Date(1548952200000l), new Date(1533173400000l), "Oracle"));
    SoftwareDAO instance = new SoftwareDAO();
    instance.actualizarElemento(elemento);
    System.out.println("Sólo se espera que cargue un mensaje confirmando la actualización");
  }

  /**
   * Prueba del método buscarElemento, de la clase SoftwareDAO.
   * Se prueba si el elemento recuperado es igual al esperado.
   */
  @Test
  public void testBuscarElemento() {
    System.out.println("buscarElemento");
    Object parametro = "Ubuntu";
    SoftwareDAO instance = new SoftwareDAO();
    Software esperado = new Software(3, "Ubuntu", "Ninguna", 16, new Licencia(
        9, 25, new Date(1548952200000l), new Date(1533173400000l), "Linux"));
    Software noEsperado = null;
    Software resultado = instance.buscarElemento(parametro);
    assertEquals(esperado, resultado);
    assertNotEquals(noEsperado, resultado);
  }
  
}
