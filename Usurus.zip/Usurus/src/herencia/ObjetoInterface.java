package herencia;

import java.util.List;

/**
 * Interfaz genérica que contiene métodos que realizan operaciones CRUD.
 * @author Jatniel Martínez
 * @param <T> Tipo de la clase entidad que implementa el objeto.
 */
public interface ObjetoInterface<T> {
  
  /**
   * Recupera todos los elementos (filas) encontrados en tal tabla de la base de datos.
   * @return Una lista con los elementos recuperados.
   */
  public List<T> consultarElementos();
  
  /**
   * Agrega un elemento (fila) en una tabla dada de la base de datos.
   * @param elemento Elemento a insertar en la tabla.
   * @return Un entero que indica si la inserción dio éxito o falló.
   */
  public int insertarElemento(T elemento);
  
  /**
   * Elimina un elemento dado (fila) de la tabla dada de la base de datos.
   * @param elemento Elemento que se va a quitar de tal tabla.
   */
  public void eliminarElemento(T elemento);
  
  /**
   * Edita uno o varios datos del elemento seleccionado (fila) de una tabla dada de la base de
   * datos.
   * @param elemento Elemento que sufrirá los cambios.
   */
  public void actualizarElemento(T elemento);
  
  /**
   * Encuentra el elemento en la base de datos.
   * @param parametro Dato del elemento a buscar.
   * @return El elemento encontrado de acuerdo al id dado.
   */
  //public T buscarElemento(T parametro);
  
}
