package herencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 * Clase que permite la conexión a la base de datos. Es abstracta para luego ser utilizada por las
 * clases entidad.
 * @author Jatniel Martínez
 * @param <T> Tipo de la entidad que implementa esta clase.
 */
public abstract class Objeto<T> implements ObjetoInterface<T> {
  
  static String usuario = "construccion";
  static String contrasena = "Pr1nc1p105(0n5+rux10n";
  static final String BASE_DATOS = "usurus";
  static final String HOST = "localhost";
  static final String ENCABEZADO = "jdbc:mysql://";
  
  protected Connection conectar() {
    Connection resultado = null;
    try {
      Class.forName("com.mysql.jdbc.Driver");
      String url = ENCABEZADO + HOST + '/' + BASE_DATOS;
      resultado = DriverManager.getConnection(url, usuario, contrasena);
    } catch (ClassNotFoundException ex) {
      JOptionPane.showMessageDialog(null, "Se produjo un error en el sistema",
          "Error del sistema", JOptionPane.ERROR_MESSAGE);
    } catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, "No es posible conectarse con la base de datos",
          "Error de conexión", JOptionPane.ERROR_MESSAGE);
    }
    return resultado;
  }
  
}
