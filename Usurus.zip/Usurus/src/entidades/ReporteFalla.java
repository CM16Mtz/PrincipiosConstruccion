package entidades;

/**
 * Entidad Reporte_falla en Java.
 * @author Jatniel Martínez
 */
public class ReporteFalla {
  
  private Integer id;
  private String descripcion;
  private Integer numReporte;
  private Hardware hardware;
  private TecnicoAcademico tecnico;
  
  /**
   * Constructor vacío. Sólo crea el reporte de falla, mas no establece sus atributos.
   */
  public ReporteFalla() {
    this.id = 0;
    this.descripcion = "";
    this.numReporte = 0;
    this.hardware = null;
    this.tecnico = null;
  }
  
  /**
   * Constructor que permite establecer todos los atributos del objeto, incluyendo el id.
   * @param id Llave primaria del elemento.
   * @param descripcion Información de la(s) falla(s) reportada(s).
   * @param numReporte Número de reporte.
   * @param hardware Hardware que presenta la(s) falla(s).
   * @param tecnico Técnico que reporta la(s) falla(s).
   */
  public ReporteFalla(Integer id, String descripcion, Integer numReporte,
      Hardware hardware, TecnicoAcademico tecnico) {
    this.id = id;
    this.descripcion = descripcion;
    this.numReporte = numReporte;
    this.hardware = hardware;
    this.tecnico = tecnico;
  }
  
  public ReporteFalla(String descripcion, Integer numReporte,
      Hardware hardware, TecnicoAcademico tecnico) {
    this.id = -1;
    this.descripcion = descripcion;
    this.numReporte = numReporte;
    this.hardware = hardware;
    this.tecnico = tecnico;
  }
  
  public void setId(Integer id) {
    this.id = id;
  }
  
  public Integer getId() {
    return this.id;
  }
  
  public void setDescripcion(String descripcion) {
    this.descripcion = descripcion;
  }
  
  public void setNumReporte(Integer numReporte) {
    this.numReporte = numReporte;
  }
  
  public void setHardware(Hardware hardware) {
    this.hardware = hardware;
  }
  
  public void setTecnicoAcademico(TecnicoAcademico tecnico) {
    this.tecnico = tecnico;
  }
  
  public String getDescripcion() {
    return descripcion;
  }
  
  public Integer getNumReporte() {
    return numReporte;
  }
  
  public Hardware getHardware() {
    return hardware;
  }
  
  public TecnicoAcademico getTecnicoAcademico() {
    return tecnico;
  }
  
  @Override
  public String toString() {
    return numReporte.toString();
  }
  
}
