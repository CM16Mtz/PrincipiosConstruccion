package entidades;

/**
 * Entidad Software en Java.
 * @author Jatniel Martínez
 */
public class Software {
  
  private Integer id;
  private String nombre;
  private String observaciones;
  private Integer version;
  private Licencia licencia;
  
  /**
   * Constructor vacío. Sólo crea el software, mas no establece sus atributos.
   */
  public Software() {
    this.id = 0;
    this.nombre = "";
    this.observaciones = "";
    this.version = 0;
    this.licencia = null;
  }
  
  /**
   * Constructor que permite establecer todos los atributos del software, incluyendo el id.
   * @param id Llave primaria del elemento
   * @param nombre Nombre que identifica al software.
   * @param observaciones Algunos detalles adicionales sobre el software.
   * @param version Versión del software.
   * @param licencia Licencia del software.
   */
  public Software(
      Integer id, String nombre, String observaciones, Integer version, Licencia licencia) {
    super();
    this.id = id;
    this.nombre = nombre;
    this.observaciones = observaciones;
    this.version = version;
    this.licencia = licencia;
  }
  
  /**
   * Constructor que permite establecer todos los atributos del software, excepto el id.
   * @param nombre Nombre que identifica al software.
   * @param observaciones Algunos detalles adicionales sobre el software.
   * @param version Versión del software.
   * @param licencia Licencia del software.
   */
  public Software(String nombre, String observaciones, Integer version, Licencia licencia) {
    this.id = -1;
    this.nombre = nombre;
    this.observaciones = observaciones;
    this.version = version;
    this.licencia = licencia;
  }
  
  public void setId(Integer id) {
    this.id = id;
  }
  
  public Integer getId() {
    return this.id;
  }
  
  public void setNombre(String nombre) {
    this.nombre = nombre;
  }
  
  public void setObservaciones(String observaciones) {
    this.observaciones = observaciones;
  }
  
  public void setVersion(Integer version) {
    this.version = version;
  }
  
  public void setLicencia(Licencia licencia) {
    this.licencia = licencia;
  }
  
  public String getNombre() {
    return nombre;
  }
  
  public String getObservaciones() {
    return observaciones;
  }
  
  public Integer getVersion() {
    return version;
  }
  
  public Licencia getLicencia() {
    return licencia;
  }
  
  @Override
  public String toString() {
    return nombre;
  }
  
}
