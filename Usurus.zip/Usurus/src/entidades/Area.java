package entidades;

/**
 * Entidad Area en Java
 * @author Jatniel Martínez
 */
public class Area {
  
  private Integer id;
  private String descripcion;
  private String numero;
  private String ubicacion;
  
  /**
   * Constructor vacío. Sólo crea el área, mas no establece sus atributos.
   */
  public Area() {
    this.id = 0;
    this.descripcion = "";
    this.numero = "";
    this.ubicacion = "";
  }
  
  /**
   * Constructor que permite establecer todos los atributos del área, incluyendo el id.
   * @param id Llave primaria del elemento.
   * @param descripcion Una breve información del área.
   * @param numero El número del área.
   * @param ubicacion La ubicación del área dentro de la facultad.
   */
  public Area(Integer id, String descripcion, String numero, String ubicacion) {
    this.id = -1;
    this.descripcion = descripcion;
    this.numero = numero;
    this.ubicacion = ubicacion;
  }
  
  /**
   * Constructor que permite establecer todos los atributos del área, excepto el id.
   * @param descripcion Una breve información del área.
   * @param numero El número del área.
   * @param ubicacion La ubicación del área dentro de la facultad.
   */
  public Area(String descripcion, String numero, String ubicacion) {
    this.id = -1;
    this.descripcion = descripcion;
    this.numero = numero;
    this.ubicacion = ubicacion;
  }
  
  public void setId(Integer id) {
    this.id = id;
  }
  
  public Integer getId() {
    return this.id;
  }
  
  public void setDescripcion(String descripcion) {
    this.descripcion = descripcion;
  }
  
  public void setNumero(String numero) {
    this.numero = numero;
  }
  
  public void setUbicacion(String ubicacion) {
    this.ubicacion = ubicacion;
  }
  
  public String getDescripcion() {
    return descripcion;
  }
  
  public String getNumero() {
    return numero;
  }
  
  public String getUbicacion() {
    return ubicacion;
  }
  
  @Override
  public String toString() {
    return numero;
  }
  
}
