package entidades;

/**
 * Entidad Responsable en Java.
 * @author Jatniel Martínez
 */
public class Responsable {
  
  private String correoElectronico;
  private String entidadAcademica;
  private String nombre;
  private String telefono;
  
  /**
   * Constructor que permite establecer todos los atributos del objeto.
   * @param correoElectronico Correo personal o institucional del responsable.
   * @param entidadAcademica Entidad en la que trabaja el responsable.
   * @param nombre Nombre completo del responsable.
   * @param telefono Teléfono del responsable.
   */
  public Responsable(String correoElectronico, String entidadAcademica, String nombre,
      String telefono) {
    this.correoElectronico = correoElectronico;
    this.entidadAcademica = entidadAcademica;
    this.nombre = nombre;
    this.telefono = telefono;
  }
  
}
