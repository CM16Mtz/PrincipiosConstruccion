package entidades;

import java.sql.Date;

/**
 * Entidad Resguardo en Java.
 * @author Jatniel Martínez
 */
public class Resguardo {
  
  private String estado;
  private Date fecha;
  private String horaDevolucion;
  private String horaPrestamo;
  
  /**
   * Constructor que permite establecer los atributos del objeto.
   * @param estado Si el resguardo está en curso o terminado.
   * @param fecha Fecha en la que se prestó el hardware.
   * @param horaDevolucion Hora en la que se devolvió el hardware.
   * @param horaPrestamo Hora en la que se prestó el hardware.
   */
  public Resguardo(String estado, Date fecha, String horaDevolucion, String horaPrestamo) {
    this.estado = estado;
    this.fecha = fecha;
    this.horaDevolucion = horaDevolucion;
    this.horaPrestamo = horaPrestamo;
  }
  
}
