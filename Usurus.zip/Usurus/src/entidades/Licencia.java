package entidades;

import java.sql.Date;

/**
 * Entidad Licencia en Java.
 * @author Jatniel Martínez
 */
public class Licencia {
  
  private Integer id;
  private Integer clave;
  private Date fechaFin;
  private Date fechaInicio;
  private String proveedor;
  
  /**
   * Constructor vacío. Sólo crea la licencia, mas no establece sus atributos.
   */
  public Licencia() {
    this.id = 0;
    this.clave = 0;
    this.fechaFin = null;
    this.fechaInicio = null;
    this.proveedor = "";
  }
  
  /**
   * Constructor que permite establecer todos los atributos de la licencia, incluyendo el id.
   * @param id Llave primaria del elemento
   * @param clave Un código numérico que identfica a la licencia.
   * @param fechaFin Fecha en la que expira la licencia.
   * @param fechaInicio Fecha en la que inició el periodo de vigencia de la licencia.
   * @param proveedor Empresa o empresario que proveyó la licencia.
   */
  public Licencia(Integer id, Integer clave, Date fechaFin, Date fechaInicio, String proveedor) {
    this.id = id;
    this.clave = clave;
    if (fechaFin != null) {
      this.fechaFin = new Date(fechaFin.getTime());
    }
    if (fechaInicio != null) {
      this.fechaInicio = new Date(fechaInicio.getTime());
    }
    this.proveedor = proveedor;
  }
  
  /**
   * Constructor que permite establecer todos los atributos de la licencia, excepto el id.
   * @param clave Un código numérico que identfica a la licencia.
   * @param fechaFin Fecha en la que expira la licencia.
   * @param fechaInicio Fecha en la que inició el periodo de vigencia de la licencia.
   * @param proveedor Empresa o empresario que proveyó la licencia.
   */
  public Licencia(Integer clave, Date fechaFin, Date fechaInicio, String proveedor) {
    this.clave = clave;
    if (fechaFin != null) {
      this.fechaFin = new Date(fechaFin.getTime());
    }
    if (fechaInicio != null) {
      this.fechaInicio = new Date(fechaInicio.getTime());
    }
    this.proveedor = proveedor;
  }
  
  public void setId(Integer id) {
    this.id = id;
  }
  
  public Integer getId() {
    return id;
  }
  
  public void setClave(Integer clave) {
    this.clave = clave;
  }
  
  public void setFechaFin(Date fechaFin) {
    if (fechaFin != null) {
      this.fechaFin = new Date(fechaFin.getTime());
    }
  }
  
  public void setFechaInicio(Date fechaInicio) {
    if (fechaInicio != null) {
      this.fechaInicio = new Date(fechaInicio.getTime());
    }
  }
  
  public void setProveedor(String proveedor) {
    this.proveedor = proveedor;
  }
  
  public Integer getClave() {
    return clave;
  }
  
  public Date getFechaFin() {
    if (fechaFin != null) {
      return new Date(fechaFin.getTime());
    } else {
      return null;
    }
  }
  
  public Date getFechaInicio() {
    if (fechaInicio != null) {
      return new Date(fechaInicio.getTime());
    } else {
      return null;
    }
  }
  
  public String getProveedor() {
    return proveedor;
  }
  
  @Override
  public String toString() {
    return clave + " - " + proveedor;
  }
  
}
