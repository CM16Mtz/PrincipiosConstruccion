package entidades;

/**
 * Entidad Hardware en Java.
 * @author Jatniel Martínez
 */
public class Hardware {
  
  private Integer id;  
  private String descripcion;
  private String estado;
  private String modelo;
  private Integer numeroInventario;
  private Integer serie;
  private String tipo;
  private Licencia licencia;
  private Area area;
  
  /**
   * Constructor vacío. Sólo crea el hardware, mas no establece sus atributos
   */
  public Hardware() {
    this.id = 0;
    this.descripcion = "";
    this.estado = "";
    this.modelo = "";
    this.numeroInventario = 0;
    this.serie = 0;
    this.tipo = "";
    this.licencia = null;
    this.area = null;
  }
  
  /**
   * Constructor que permite establecer todos los atributos del objeto, incluyendo el id.
   * @param id Llave primaria del elemento.
   * @param descripcion Información que describe al hardware.
   * @param estado Dice si el hardware está bien o tiene defectos.
   * @param modelo Modelo del hardware.
   * @param numeroInventario Un número que identifica al hardware.
   * @param serie El número de serie del hardware.
   * @param tipo Clase del hardware.
   * @param licencia Licencia del hardware.
   * @param area Área en la que se encuentra el hardware.
   */
  public Hardware(Integer id, String descripcion, String estado, String modelo,
      Integer numeroInventario, Integer serie, String tipo, Licencia licencia, Area area) {
    super();
    this.id = id;
    this.descripcion = descripcion;
    this.estado = estado;
    this.modelo = modelo;
    this.numeroInventario = numeroInventario;
    this.serie = serie;
    this.tipo = tipo;
    this.licencia = licencia;
    this.area = area;
  }
  
  /**
   * Constructor que permite establecer todos los atributos del objeto, excepto el id.
   * @param descripcion Información que describe al hardware.
   * @param estado Dice si el hardware está bien o tiene defectos.
   * @param modelo Modelo del hardware.
   * @param numeroInventario Un número que identifica al hardware.
   * @param serie El número de serie del hardware.
   * @param tipo Clase del hardware.
   * @param licencia Licencia del hardware.
   * @param area Área en la que se encuentra el hardware.
   */
  public Hardware(String descripcion, String estado, String modelo, Integer numeroInventario,
      Integer serie, String tipo, Licencia licencia, Area area) {
    this.id = -1;
    this.descripcion = descripcion;
    this.estado = estado;
    this.modelo = modelo;
    this.numeroInventario = numeroInventario;
    this.serie = serie;
    this.tipo = tipo;
    this.licencia = licencia;
    this.area = area;
  }
  
  public void setId(Integer id) {
    this.id = id;
  }
  
  public Integer getId() {
    return this.id;
  }
  
  public void setDescripcion(String descripcion) {
    this.descripcion = descripcion;
  }
  
  public void setEstado(String estado) {
    this.estado = estado;
  }
  
  public void setModelo(String modelo) {
    this.modelo = modelo;
  }
  
  public void setNumeroInventario(Integer numeroInventario) {
    this.numeroInventario = numeroInventario;
  }
  
  public void setSerie(Integer serie) {
    this.serie = serie;
  }
  
  public void setTipo(String tipo) {
    this.tipo = tipo;
  }
  
  public void setArea(Area area) {
    this.area = area;
  }
  
  public void setLicencia(Licencia licencia) {
    this.licencia = licencia;
  }
  
  public String getDescripcion() {
    return descripcion;
  }
  
  public String getEstado() {
    return estado;
  }
  
  public String getModelo() {
    return modelo;
  }
  
  public Integer getNumeroInventario() {
    return numeroInventario;
  }
  
  public Integer getSerie() {
    return serie;
  }
  
  public String getTipo() {
    return tipo;
  }
  
  public Area getArea() {
    return area;
  }
  
  public Licencia getLicencia() {
    return licencia;
  }
  
  @Override
  public String toString() {
    return serie + " - " + modelo + " - " + tipo;
  }
  
}
