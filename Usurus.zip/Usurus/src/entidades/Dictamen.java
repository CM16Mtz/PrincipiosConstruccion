package entidades;

import java.sql.Date;

/**
 * Entidad Dictamen en Java
 * @author Jatniel Martínez
 */
public class Dictamen {
  
  private final Integer id;
  private String descripcion;
  private Date fechaDictamen;
  private String observacion;
  private String tipo;
  private ReporteFalla reporte;
  private TecnicoAcademico tecnico;
  
  /**
   * Constructor vacío. Sólo crea el dictamen, mas no establece sus atributos.
   */
  public Dictamen() {
    this.id = 0;
    this.descripcion = "";
    this.fechaDictamen = null;
    this.observacion = "";
    this.tipo = "";
    this.reporte = null;
    this.tecnico = null;
  }
  
  /**
   * Constructor que permite establecer todos los atributos del objeto, incluyendo el id.
   * @param id Llave primaria del elemento.
   * @param descripcion Información que otorga el dictamen.
   * @param fechaDictamen Fecha en la que se crea el dictamen.
   * @param observacion Información adicional.
   * @param tipo Tipo al que pertenece el dictamen.
   * @param reporte Reporte de falla que incluye el dictamen.
   * @param tecnico Técnico que elabora el dictamen.
   */
  public Dictamen(Integer id, String descripcion, Date fechaDictamen, String observacion,
      String tipo, ReporteFalla reporte, TecnicoAcademico tecnico) {
    this.id = id;
    this.descripcion = descripcion;
    if (fechaDictamen != null) {
      this.fechaDictamen = new Date(fechaDictamen.getTime());
    }
    this.observacion = observacion;
    this.tipo = tipo;
    this.reporte = reporte;
    this.tecnico = tecnico;
  }
  
  /**
   * Constructor que permite establecer todos los atributos del objeto, excepto el id.
   * @param descripcion Información que otorga el dictamen.
   * @param fechaDictamen Fecha en la que se crea el dictamen.
   * @param observacion Información adicional.
   * @param tipo Tipo al que pertenece el dictamen.
   * @param reporte Reporte de falla que incluye el dictamen.
   * @param tecnico Técnico que elabora el dictamen.
   */
  public Dictamen(String descripcion, Date fechaDictamen, String observacion, String tipo,
      ReporteFalla reporte, TecnicoAcademico tecnico) {
    this.id = -1;
    this.descripcion = descripcion;
    if (fechaDictamen != null) {
      this.fechaDictamen = new Date(fechaDictamen.getTime());
    }
    this.observacion = observacion;
    this.tipo = tipo;
    this.reporte = reporte;
    this.tecnico = tecnico;
  }
  
  public Integer getId() {
    return this.id;
  }
  
  public void setDescripcion(String descripcion) {
    this.descripcion = descripcion;
  }
  
  public void setFechaDictamen(Date fechaDictamen) {
    if (fechaDictamen != null) {
      this.fechaDictamen = new Date(fechaDictamen.getTime());
    }
  }
  
  public void setObservacion(String observacion) {
    this.observacion = observacion;
  }
  
  public void setTipo(String tipo) {
    this.tipo = tipo;
  }
  
  public void setReporteFalla(ReporteFalla reporte) {
    this.reporte = reporte;
  }
  
  public void setTecnicoAcademico(TecnicoAcademico tecnico) {
    this.tecnico = tecnico;
  }
  
  public String getDescripcion() {
    return descripcion;
  }
  
  public Date getFechaDictamen() {
    if (fechaDictamen != null) {
      return new Date (fechaDictamen.getTime());
    } else {
      return null;
    }
  }
  
  public String getObservacion() {
    return observacion;
  }
  
  public String getTipo() {
    return tipo;
  }
  
  public ReporteFalla getReporteFalla() {
    return reporte;
  }
  
  public TecnicoAcademico getTecnicoAcademico() {
    return tecnico;
  }
  
}
