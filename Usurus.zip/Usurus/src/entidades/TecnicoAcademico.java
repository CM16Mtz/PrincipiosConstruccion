package entidades;

/**
 * Entidad Tecnico_academico en Java.
 * @author Jatniel Martínez
 */
public class TecnicoAcademico {
  
  private Integer id;
  private String correoElectronico;
  private String entidadAcademica;
  private String nombre;
  private String noPersonal;
  private String telefono;
  
  /**
   * Constructor vacío. Sólo crea el técnico académico, mas no establece sus atributos.
   */
  public TecnicoAcademico() {
    this.id = 0;
    this.correoElectronico = "";
    this.entidadAcademica = "";
    this.nombre = "";
    this.noPersonal = "";
    this.telefono = "";
  }
  
  /**
   * Constructor que permite establecer todos los atributos del objeto, incluyendo el id.
   * @param id Llave primaria del elemento.
   * @param correoElectronico Correo del técnico.
   * @param entidadAcademica Entidad en la que trabaja el técnico.
   * @param nombre Nombre completo del técnico.
   * @param noPersonal Identificador del técnico.
   * @param telefono Teléfono del técnico
   */
  public TecnicoAcademico(Integer id, String correoElectronico, String entidadAcademica,
      String nombre, String noPersonal, String telefono) {
    this.id = id;
    this.correoElectronico = correoElectronico;
    this.entidadAcademica = entidadAcademica;
    this.nombre = nombre;
    this.noPersonal = noPersonal;
    this.telefono = telefono;
  }
  
  /**
   * Constructor que permite establecer todos los atributos del objeto, excepto el id.
   * @param correoElectronico Correo del técnico.
   * @param entidadAcademica Entidad en la que trabaja el técnico.
   * @param nombre Nombre completo del técnico.
   * @param noPersonal Identificador del técnico.
   * @param telefono Teléfono del técnico
   */
  public TecnicoAcademico(String correoElectronico, String entidadAcademica, String nombre,
      String noPersonal, String telefono) {
    this.id = -1;
    this.correoElectronico = correoElectronico;
    this.entidadAcademica = entidadAcademica;
    this.nombre = nombre;
    this.noPersonal = noPersonal;
    this.telefono = telefono;
  }
  
  public void setId(Integer id) {
    this.id = id;
  }
  
  public Integer getId() {
    return this.id;
  }
  
  public void setCorreoElectronico(String correoElectronico) {
    this.correoElectronico = correoElectronico;
  }
  
  public void setEntidadAcademica(String entidadAcademica) {
    this.entidadAcademica = entidadAcademica;
  }
  
  public void setNombre(String nombre) {
    this.nombre = nombre;
  }
  
  public void setNoPersonal(String noPersonal) {
    this.noPersonal = noPersonal;
  }
  
  public void setTelefono(String telefono) {
    this.telefono = telefono;
  }
  
  public String getCorreoElectronico() {
    return correoElectronico;
  }
  
  public String getEntidadAcademica() {
    return entidadAcademica;
  }
  
  public String getNombre() {
    return nombre;
  }
  
  public String getNoPersonal() {
    return noPersonal;
  }
  
  public String getTelefono() {
    return telefono;
  }
  
  @Override
  public String toString() {
    return noPersonal + " - " + nombre;
  }
  
}
