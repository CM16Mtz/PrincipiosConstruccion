package dao;

import entidades.Licencia;
import herencia.Objeto;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 * Clase que utiliza la operación Consultar para recuperar los elementos de la base de datos.
 * A pesar de que la clase hereda de Objeto.java, por esta ocasión, no se utilizarán todos los
 * métodos que debe implementar LicenciaDAO.
 * @author Jatniel Martínez
 */
public class LicenciaDAO extends Objeto<Licencia> {

  @Override
  public List<Licencia> consultarElementos() {
    Connection conexion = this.conectar();
    PreparedStatement consulta = null;
    try {
      consulta = conexion.prepareStatement("SELECT * FROM Licencia l");
      ResultSet resultado = consulta.executeQuery();
      List<Licencia> lista = new ArrayList<>();
      while (resultado.next()) {
        Integer id = resultado.getInt("idLicencia");
        Integer clave = resultado.getInt("clave");
        Date fechaFin = resultado.getDate("fechaFin");
        Date fechaInicio = resultado.getDate("fechaInicio");
        String proveedor = resultado.getString("proveedor");
        lista.add(new Licencia(id, clave, fechaFin, fechaInicio, proveedor));
      }
      return lista;
    } catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, "No es posible recuperar la información",
          "Error de consulta", JOptionPane.ERROR_MESSAGE);
    } finally {
      try {
        conexion.close();
      } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Se produjo un error al recuperar la información",
            "Error", JOptionPane.ERROR_MESSAGE);
      }
    }
    return null;
  }

  @Override
  public int insertarElemento(Licencia elemento) {
    throw new UnsupportedOperationException("Método no utilizado.");
  }

  @Override
  public void eliminarElemento(Licencia elemento) {
    throw new UnsupportedOperationException("Método no utilizado.");
  }

  @Override
  public void actualizarElemento(Licencia elemento) {
    throw new UnsupportedOperationException("Método no utilizado.");
  }

  //@Override
  public Licencia buscarElemento(Object parametro) {
    throw new UnsupportedOperationException("Método no utilizado.");
  }
  
}
