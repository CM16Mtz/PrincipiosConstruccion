package dao;

import entidades.Area;
import herencia.Objeto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 * Clase que utiliza la operación Consultar para recuperar los elementos de la base de datos.
 * A pesar de que la clase hereda de Objeto.java, por esta ocasión, no se utilizarán todos los
 * métodos que debe implementar AreaDAO.
 * @author Jatniel Martínez
 */
public class AreaDAO extends Objeto<Area> {

  @Override
  public List<Area> consultarElementos() {
    Connection conexion = this.conectar();
    PreparedStatement consulta = null;
    try {
      consulta = conexion.prepareStatement("SELECT * FROM Area a");
      ResultSet resultado = consulta.executeQuery();
      List<Area> lista = new ArrayList<>();
      while (resultado.next()) {
        Integer id = resultado.getInt("idArea");
        String descripcion = resultado.getString("descripcion");
        String numero = resultado.getString("numero");
        String ubicacion = resultado.getString("ubicacion");
        lista.add(new Area(id, descripcion, numero, ubicacion));
      }
      return lista;
    } catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, "No es posible recuperar la información",
          "Error de consulta", JOptionPane.ERROR_MESSAGE);
    } finally {
      try {
        conexion.close();
      } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Se produjo un error al recuperar la información",
            "Error", JOptionPane.ERROR_MESSAGE);
      }
    }
    return null;
  }

  @Override
  public int insertarElemento(Area elemento) {
    throw new UnsupportedOperationException("Método no utilizado.");
  }

  @Override
  public void eliminarElemento(Area elemento) {
    throw new UnsupportedOperationException("Método no utilizado.");
  }

  @Override
  public void actualizarElemento(Area elemento) {
    throw new UnsupportedOperationException("Método no utilizado.");
  }
  
}
