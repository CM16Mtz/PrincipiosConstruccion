package dao;

import entidades.Dictamen;
import herencia.Objeto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import javax.swing.JOptionPane;

/**
 * Clase que utiliza la operación Insertar para registrar dictámenes en la base de datos.
 * A pesar de que la clase hereda de Objeto.java, por esta ocasión, no se utilzarán todos los
 * métodos que debe implementar DictamenDAO.
 * @author Jatniel Martínez
 */
public class DictamenDAO extends Objeto<Dictamen> {

  @Override
  public List<Dictamen> consultarElementos() {
    throw new UnsupportedOperationException("Método no utilizado.");
  }

  @Override
  public int insertarElemento(Dictamen elemento) {
    Connection conexion = this.conectar();
    PreparedStatement consulta = null;
    try {
      consulta = conexion.prepareStatement("INSERT INTO Dictamen VALUES("
          + "default, ?, ?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
      consulta.setString(1, elemento.getDescripcion());
      consulta.setDate(2, elemento.getFechaDictamen());
      consulta.setString(3, elemento.getObservacion());
      consulta.setString(4, elemento.getTipo());
      consulta.setInt(5, elemento.getReporteFalla().getId());
      consulta.setInt(6, elemento.getTecnicoAcademico().getId());
      consulta.executeUpdate();
      ResultSet resultado = consulta.getGeneratedKeys();
      resultado.next();
      int id = resultado.getInt(1);
      return id;
    } catch (SQLException ex) {
      JOptionPane.showMessageDialog(null, "No es posible guardar el dictamen",
          "Error de registro", JOptionPane.ERROR_MESSAGE);
    } finally {
      try {
        conexion.close();
      } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Se produjo un error al guardar la actividad",
            "Error", JOptionPane.ERROR_MESSAGE);
      }
    }
    return -1;
  }

  @Override
  public void eliminarElemento(Dictamen elemento) {
    throw new UnsupportedOperationException("Método no utilizado");
  }

  @Override
  public void actualizarElemento(Dictamen elemento) {
    throw new UnsupportedOperationException("Método no utilizado");
  }

  //@Override
  public Dictamen buscarElemento(Object parametro) {
    throw new UnsupportedOperationException("Método no utilizado");
  }
  
}
